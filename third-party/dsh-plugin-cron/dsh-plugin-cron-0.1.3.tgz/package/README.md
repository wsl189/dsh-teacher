# dsh-plugin-cron

**Cron scheduler plugin for DeepSeek Harness (DSH).** Model-facing `cron_add` / `cron_list` / `cron_remove` / `cron_run` tools, durable job persistence, shell-command execution, plus a browser sidebar entry and a full-page management UI.

定时任务插件：让 AI（以及浏览器端页面）直接管理 DSH 上的定时命令。同时包含**服务端**（调度 + HTTP 接口）和**浏览器端**（侧边栏入口 + 全屏管理页）两部分。

## 功能

### 服务端工具（面向模型）

| 工具 | 作用 |
|------|------|
| `cron_add` | 新增或更新一个定时命令 |
| `cron_list` | 列出任务、下次运行时间、上次结果 |
| `cron_remove` | 按名称删除任务 |
| `cron_run` | 立即手动运行一次（测试用） |

### HTTP 接口（`/cron-api`）

| 接口 | 作用 |
|------|------|
| `GET /cron-api/jobs` | 列出任务及当前 `running` 状态 |
| `POST /cron-api/jobs` | 新增/更新任务（JSON 请求体） |
| `DELETE /cron-api/jobs/<名称>` | 删除任务（连同执行记录） |
| `POST /cron-api/jobs/<名称>/run` | 立即运行一次 |
| `POST /cron-api/jobs/<名称>/enabled` | 启用/停用（body：`{"enabled": true\|false}`） |
| `GET /cron-api/jobs/<名称>/runs` | 查看执行记录（新的在前） |

### 浏览器端

- **侧边栏入口**：位于「新会话」与「工作区」之间；显示已启用或正在执行的任务数，点击整行直接在右侧打开管理页，不在侧栏下拉任务列表。当前会话活动会立即触发数量刷新，定期刷新负责兜底。
- **折叠侧栏**：保留时钟图标，点击后直接打开右侧管理页。
- **全屏管理页**：任务表格（下次运行时间、上次状态）、新增表单、运行/启用/删除按钮，以及每个任务的**执行记录**（可展开查看每次的输出）。“操作手册”和“新增定时任务”默认收起。
- **工作台提醒投影**：安装教师工作台时，定时任务列表会显示其未完成手机提醒；提醒仍由工作台文档与发送运行时拥有，并且在定时任务管理页中只读。

## 安装

```bash
dsh plugin --profile web add dsh-plugin-cron
```

`cordis.patch.yml`（package.json 的 `dsh.bundle.patch` 声明）会自动把 `dsh-plugin-cron` 注册进 bundle 栈；也可以手动在 profile 的 `package.json` 里把 `dsh-plugin-cron` 加进 `dependencies` 和 `bundles`。

> 本包通过 peerDependencies 共享宿主的 `@deepseek-ai/*` 实例，**不要**把 `@deepseek-ai/*` 物理装进本包，否则会出现双实例导致崩溃。

## 定时表达式

标准 5 段 cron：`分钟 小时 日 月 星期`

- 分钟 0-59、小时 0-23、日 1-31、月 1-12（或 JAN-DEC）、星期 0-7（SUN-SAT，0 和 7 都是周日）
- 每段支持：`*`（所有值）、`?`（同 `*`）、`a-b`（区间）、`*/n` / `a/n`（步进）、`a,b,c`（列表）
- 别名：`@yearly` `@annually` `@monthly` `@weekly` `@daily` `@midnight` `@hourly`
- 日与星期**同时限制**时按「或」触发（Vixie cron 语义）

例子：`0 9 * * 1-5`（工作日 9 点）、`*/15 * * * *`（每 15 分钟）、`0 0 1 * *`（每月 1 号 0 点）。

## 行为说明

- **持久化**：任务与执行记录存于 DSH 存储中心的 `cron` 单元（`jobs` / `runs` 表），重启服务不丢失。
- **执行方式**：到点任务通过标准 `ctx.shell` 执行器运行，**与 dsh 进程同权限（不沙箱，请求 danger-full-access）**，请只安排可信命令。
- **不补跑**：停机期间错过的任务不补跑，重启后从当前时间重新计算下次。
- **不重叠**：同一任务上一次还没跑完时，下一次触发会被跳过。
- **扫描粒度**：每 1 秒检查一次到点任务。
- **超时**：每个任务可设 `timeoutMs`，默认 300 秒，上限 600 秒。
- **记录上限**：每个任务保留最近 **10** 条执行记录；`lastOutput` 截断 **4 KB**，历史单条输出截断 **8 KB**。

## 目录结构

```
lib/cron.js       纯 5 段 cron 解析器（无依赖）
lib/index.js      服务端：工具 + 调度循环 + 持久化 + /cron-api 路由
lib/client.js     浏览器端：侧边栏 + 全屏管理页（window.__ModuleLoader__ bundle）
cordis.patch.yml  bundle 补丁层（注册插件行）
test/             测试
```

## 测试

```powershell
node test\cron.test.mjs        # cron 解析器断言
node test\plugin.test.mjs      # fake-ctx 集成断言
node test\real-boot.test.mjs   # 真实 Cordis + 真实存储断言
```

## 开发注意事项

- `lib/client.js` 的样式对象里，`var(--...)` 主题 token 要先在样式对象**之外**解析成局部常量，再在对象内部引用，避免 TDZ 自引用（`Cannot access 's' before initialization`）。
- 不要在本包内物理安装 `@deepseek-ai/*`，通过 peerDependencies 共享宿主实例，保证单实例。

## License

[MIT](./LICENSE)
