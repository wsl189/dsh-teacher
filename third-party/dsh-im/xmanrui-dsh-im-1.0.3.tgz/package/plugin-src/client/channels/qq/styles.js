export const QQ_STYLE_ID = 'xmanrui-dsh-im-qq-settings';

const CSS = String.raw`
.dqq-page { --ddt-accent: #1677ff; --ddt-accent-deep: #0958d9; --ddt-accent-wash: #eaf3ff; }
.dqq-avatar, .dqq-brand { color: #fff; background: #1677ff; }
.dqq-avatar svg, .dqq-brand svg { display: block; }
.dqq-nameEditor { display: grid; gap: 6px; margin-top: 6px; padding: 9px 10px; border: 1px solid var(--dsw-alias-border-l1, #eef0f3); border-radius: 9px; background: var(--dsw-alias-bg-module-platform, #f7f8fa); }
.dqq-nameEditor > label { color: var(--dsw-alias-label-secondary, #646a73); font-size: 12px; line-height: normal; }
.dqq-nameControls { display: grid; grid-template-columns: minmax(0, 1fr) max-content; gap: 8px; }
.dqq-nameControls input { min-width: 0; height: 32px; padding: 0 9px; border: 1px solid var(--dsw-alias-border-l2, #dfe1e5); border-radius: 7px; outline: none; color: var(--dsw-alias-label-primary, #1f2329); background: var(--dsw-alias-bg-layer-1, #fff); font: inherit; font-size: 13px; }
.dqq-nameControls input:focus { border-color: #1677ff; box-shadow: 0 0 0 2px rgb(22 119 255 / 12%); }
.dqq-nameControls .dqq-nameSave { min-height: 32px; padding: 0 11px; }
.dqq-nameError { margin: 0; color: var(--dsw-alias-state-error-primary, #d54941); font-size: 12px; line-height: 1.4; }
.dqq-speechCard { margin-bottom: 16px; }
.dqq-speechForm { display: grid; gap: 16px; }
.dqq-speechHeading { display: flex; align-items: flex-start; justify-content: space-between; gap: 20px; }
.dqq-speechHeading h3 { margin: 0; color: var(--dsw-alias-label-primary, #1f2329); font-size: 17px; line-height: 1.4; }
.dqq-speechHeading p { margin: 4px 0 0; color: var(--dsw-alias-label-secondary, #646a73); font-size: 13px; line-height: 1.6; }
.dqq-speechToggle, .dqq-clearKey { white-space: nowrap; }
.dqq-speechToggle[aria-pressed="true"] { border-color: #1677ff; color: #0958d9; background: #eaf3ff; }
.dqq-clearKey { min-height: 28px; justify-self: start; padding: 0 8px; font-size: 12px; }
.dqq-clearKey[aria-pressed="true"] { border-color: var(--dsw-alias-state-error-primary, #d54941); color: var(--dsw-alias-state-error-primary, #d54941); }
.dqq-speechGrid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }
.dqq-speechField { display: grid; gap: 6px; color: var(--dsw-alias-label-secondary, #646a73); font-size: 12px; }
.dqq-speechWide { grid-column: 1 / -1; }
.dqq-speechField input { min-width: 0; height: 38px; padding: 0 11px; border: 1px solid var(--dsw-alias-border-l2, #dfe1e5); border-radius: 8px; outline: none; color: var(--dsw-alias-label-primary, #1f2329); background: var(--dsw-alias-bg-layer-1, #fff); font: inherit; font-size: 13px; }
.dqq-speechField input:focus { border-color: #1677ff; box-shadow: 0 0 0 2px rgb(22 119 255 / 12%); }
.dqq-speechField input:disabled { cursor: not-allowed; opacity: .65; }
.dqq-speechFooter { display: flex; align-items: flex-end; justify-content: space-between; gap: 16px; }
.dqq-speechMeta { display: grid; gap: 6px; color: var(--dsw-alias-label-secondary, #646a73); font-size: 12px; line-height: 1.4; }
.dqq-speechFeedback[data-tone="success"] { color: var(--dsw-alias-state-success-primary, #2f9b65); }
.dqq-speechFeedback[data-tone="error"] { color: var(--dsw-alias-state-error-primary, #d54941); }
@media (max-width: 720px) {
  .dqq-speechHeading, .dqq-speechFooter { align-items: stretch; flex-direction: column; }
  .dqq-speechGrid { grid-template-columns: 1fr; }
  .dqq-speechWide { grid-column: auto; }
  .dqq-speechFooter .ddt-button { width: 100%; }
}
`;

export function installQqStyles() {
  if (typeof document === 'undefined') return () => {};
  const existing = document.querySelector(`style[data-plugin-css="${QQ_STYLE_ID}"]`);
  if (existing) return () => {};
  const style = document.createElement('style');
  style.dataset.plugin = '@xmanrui/dsh-im';
  style.dataset.pluginCss = QQ_STYLE_ID;
  style.textContent = CSS;
  document.head.appendChild(style);
  return () => style.remove();
}
