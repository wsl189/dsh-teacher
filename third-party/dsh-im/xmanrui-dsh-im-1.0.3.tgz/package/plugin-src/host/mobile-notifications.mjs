const registries = new WeakMap();

function nonEmpty(value, name) {
  if (typeof value !== 'string' || value.trim() === '') {
    throw new TypeError(`${name} must be a non-empty string`);
  }
  return value.trim();
}

function botLabel(bot, botId) {
  return bot?.bot?.name ?? bot?.name ?? bot?.label ?? botId;
}

/** Install the credential-free notification service consumed by DSH features. */
export function installMobileNotifications(ctx) {
  if (typeof ctx?.provide !== 'function' || typeof ctx?.effect !== 'function') return;
  const registry = { controllers: new Map() };
  registries.set(ctx, registry);
  ctx.provide('mobileNotifications', Object.freeze({
    async listTargets() {
      const targets = [];
      for (const [channel, controller] of registry.controllers) {
        const status = await controller.status();
        for (const bot of status?.bots ?? []) {
          const botId = nonEmpty(bot?.botId, `${channel} botId`);
          targets.push(Object.freeze({
            channel,
            botId,
            label: nonEmpty(botLabel(bot, botId), `${channel} bot label`),
            connected: bot?.connected === true,
          }));
        }
      }
      return Object.freeze(targets);
    },
    async send(request) {
      const channel = nonEmpty(request?.channel, 'channel');
      const botId = nonEmpty(request?.botId, 'botId');
      const text = nonEmpty(request?.text, 'text');
      const controller = registry.controllers.get(channel);
      if (!controller || typeof controller.sendNotification !== 'function') {
        throw new Error(`Notification channel is unavailable: ${channel}`);
      }
      await controller.sendNotification(botId, text);
    },
  }));
  ctx.effect(() => () => {
    registry.controllers.clear();
    registries.delete(ctx);
  }, 'dsh-im: clear mobile notification targets');
}

/** Register one channel controller with the host-level notification service. */
export function registerMobileNotificationController(ctx, channel, controller) {
  const registry = registries.get(ctx);
  if (!registry) return;
  registry.controllers.set(channel, controller);
  ctx.effect(() => () => {
    if (registry.controllers.get(channel) === controller) registry.controllers.delete(channel);
  }, `dsh-im: unregister ${channel} notification controller`);
}
