import { realpath, stat } from 'node:fs/promises';
import { homedir } from 'node:os';
import { basename, extname, isAbsolute, relative, resolve } from 'node:path';

const IMAGE_EXTENSIONS = new Set(['.gif', '.jpeg', '.jpg', '.png', '.webp']);
const IMAGE_MAX_BYTES = 30 * 1024 * 1024;
const FILE_MAX_BYTES = 100 * 1024 * 1024;
const MAX_PATH_LENGTH = 4_096;
const UNSAFE_PATH = /[\p{Cc}\p{Cf}\p{Zl}\p{Zp}]/u;

function cleanString(value) {
  return typeof value === 'string' && value.trim() ? value.trim() : null;
}

function toolError(code, message, cause) {
  const error = new Error(message, cause === undefined ? undefined : { cause });
  error.code = code;
  return error;
}

function safeAbsolutePath(value) {
  const path = cleanString(value);
  if (!path || path.length > MAX_PATH_LENGTH || !isAbsolute(path) || UNSAFE_PATH.test(path)) {
    throw toolError('qq-media-path-invalid', 'QQ media path must be a safe absolute path.');
  }
  return resolve(path);
}

function pathInside(root, path) {
  const child = relative(root, path);
  return child === '' || (!child.startsWith('..') && !isAbsolute(child));
}

async function existingDirectory(value, { optional = false } = {}) {
  const path = safeAbsolutePath(value);
  try {
    const canonical = resolve(await realpath(path));
    if (!(await stat(canonical)).isDirectory()) {
      throw toolError('qq-media-root-invalid', `QQ outbound media root is not a directory: ${path}`);
    }
    return canonical;
  } catch (error) {
    if (optional && error?.code === 'ENOENT') return null;
    if (error?.code === 'qq-media-root-invalid') throw error;
    throw toolError('qq-media-root-invalid', `QQ outbound media root is unavailable: ${path}`, error);
  }
}

async function configuredRoots(values) {
  if (values !== undefined && !Array.isArray(values)) {
    throw new TypeError('qq.outboundMediaRoots must be an array of absolute directory paths');
  }
  if (values?.length) {
    return Object.freeze(await Promise.all(values.map((value) => existingDirectory(value))));
  }
  const desktop = await existingDirectory(resolve(homedir(), 'Desktop'), { optional: true });
  return Object.freeze(desktop ? [desktop] : []);
}

function routePromptRpcId(agent, promptRpcIds) {
  let openTurn = null;
  let matched = null;
  for (const event of agent?.session?.events ?? []) {
    if (event?.type === 'turn/start') {
      openTurn = event.data?.turn ?? null;
      matched = null;
      continue;
    }
    if (event?.type === 'turn/end' && event.data?.turn === openTurn) {
      openTurn = null;
      matched = null;
      continue;
    }
    if (openTurn !== null
      && event?.type === 'user/message'
      && promptRpcIds.has(event.data?.source?.rpcId)) {
      matched = event.data.source.rpcId;
    }
  }
  return matched;
}

async function sessionWorkspace(agent) {
  const cwd = cleanString(agent?.session?.header?.cwd);
  return cwd ? existingDirectory(cwd) : null;
}

async function resolveMediaFile(pathValue, kind, agent, roots) {
  const requested = safeAbsolutePath(pathValue);
  let canonical;
  let info;
  try {
    canonical = resolve(await realpath(requested));
    info = await stat(canonical);
  } catch (error) {
    throw toolError('qq-media-not-found', `QQ media file is unavailable: ${requested}`, error);
  }
  if (!info.isFile()) {
    throw toolError('qq-media-not-file', `QQ media path is not a regular file: ${requested}`);
  }
  const workspace = await sessionWorkspace(agent);
  const allowedRoots = workspace ? [workspace, ...roots] : roots;
  if (!allowedRoots.some((root) => pathInside(root, canonical))) {
    throw toolError(
      'qq-media-path-denied',
      'QQ can send only files inside the current Harness workspace or qq.outboundMediaRoots.',
    );
  }
  const maxBytes = kind === 'image' ? IMAGE_MAX_BYTES : FILE_MAX_BYTES;
  if (info.size > maxBytes) {
    throw toolError(
      'qq-media-too-large',
      `QQ ${kind} exceeds the ${Math.round(maxBytes / 1024 / 1024)} MB upload limit.`,
    );
  }
  if (kind === 'image' && !IMAGE_EXTENSIONS.has(extname(canonical).toLowerCase())) {
    throw toolError('qq-media-image-type', 'QQ images must be GIF, JPEG, PNG, or WebP files.');
  }
  return canonical;
}

function validateArguments(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw toolError('qq-media-arguments-invalid', 'qq_send_local_file requires an argument object.');
  }
  const keys = Object.keys(value);
  if (keys.some((key) => !['path', 'kind', 'caption'].includes(key))) {
    throw toolError('qq-media-arguments-invalid', 'qq_send_local_file received an unknown argument.');
  }
  const path = cleanString(value.path);
  const kind = value.kind;
  const caption = value.caption === undefined ? null : cleanString(value.caption);
  if (!path || !['image', 'file'].includes(kind)
    || (value.caption !== undefined && caption === null)) {
    throw toolError(
      'qq-media-arguments-invalid',
      'qq_send_local_file requires path, kind=image|file, and an optional non-empty caption.',
    );
  }
  return { path, kind, ...(caption ? { caption } : {}) };
}

function toolDefinition(router) {
  return {
    name: 'qq_send_local_file',
    description: 'Send one local image or file to the QQ conversation that owns the current turn. Use only when that QQ user explicitly asks to receive the file. The path must be absolute and inside the session workspace or an administrator-configured QQ media root.',
    parameters: {
      type: 'object',
      additionalProperties: false,
      required: ['path', 'kind'],
      properties: {
        path: { type: 'string', description: 'Absolute path of the local file to send.' },
        kind: { type: 'string', enum: ['image', 'file'], description: 'Use image for GIF/JPEG/PNG/WebP display; otherwise use file.' },
        caption: { type: 'string', description: 'Optional short message sent with the QQ upload.' },
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        required: ['sent', 'kind', 'name'],
        properties: {
          sent: { type: 'boolean' },
          kind: { type: 'string', enum: ['image', 'file'] },
          name: { type: 'string' },
        },
      },
      render(_args, value) {
        const label = value.kind === 'image' ? '图片' : '文件';
        return [{ type: 'text', text: `已通过 QQ 发送${label}：${value.name}` }];
      },
    },
    execute(args, exec) {
      return router.send(args, exec);
    },
  };
}

/** Route one model-requested local upload to the QQ conversation that owns its turn. */
export class QqOutboundMedia {
  #roots;
  #routes = new Map();
  #disposeTool;

  static async install(ctx, { outboundMediaRoots } = {}) {
    if (!ctx?.tools || typeof ctx.tools.register !== 'function') {
      throw new TypeError('dsh-im QQ outbound media requires ctx.tools');
    }
    const router = new QqOutboundMedia(await configuredRoots(outboundMediaRoots));
    router.#disposeTool = ctx.tools.register(toolDefinition(router));
    return router;
  }

  constructor(roots = []) {
    this.#roots = Object.freeze([...roots]);
  }

  /** Bind one pending Harness prompt to its private QQ target until the ask settles. */
  bind({ sessionId, promptRpcId, target, bot }) {
    if (!cleanString(sessionId) || !cleanString(promptRpcId)
      || !target || !['c2c', 'group'].includes(target.scope)
      || !cleanString(target.targetId)
      || !bot || typeof bot.sendImage !== 'function' || typeof bot.sendFile !== 'function') {
      throw new TypeError('A Harness prompt and media-capable QQ target are required');
    }
    const routes = this.#routes.get(sessionId) ?? new Map();
    if (routes.has(promptRpcId)) throw new Error(`Duplicate QQ media route: ${promptRpcId}`);
    routes.set(promptRpcId, Object.freeze({ target: structuredClone(target), bot }));
    this.#routes.set(sessionId, routes);
    let active = true;
    return () => {
      if (!active) return;
      active = false;
      routes.delete(promptRpcId);
      if (routes.size === 0 && this.#routes.get(sessionId) === routes) {
        this.#routes.delete(sessionId);
      }
    };
  }

  async send(rawArgs, exec) {
    const args = validateArguments(rawArgs);
    const sessionId = cleanString(exec?.agent?.id);
    const routes = sessionId ? this.#routes.get(sessionId) : null;
    const promptRpcId = routes
      ? routePromptRpcId(exec.agent, new Set(routes.keys()))
      : null;
    const route = promptRpcId ? routes.get(promptRpcId) : null;
    if (!route) {
      throw toolError(
        'qq-media-route-unavailable',
        'qq_send_local_file is available only during the QQ turn that requested the upload.',
      );
    }
    exec.signal?.throwIfAborted();
    const path = await resolveMediaFile(args.path, args.kind, exec.agent, this.#roots);
    exec.signal?.throwIfAborted();
    if (args.kind === 'image') {
      await route.bot.sendImage(route.target, { localPath: path }, {
        ...(args.caption ? { content: args.caption } : {}),
      });
    } else {
      await route.bot.sendFile(route.target, { localPath: path }, {
        fileName: basename(path),
        ...(args.caption ? { content: args.caption } : {}),
      });
    }
    return Object.freeze({ sent: true, kind: args.kind, name: basename(path) });
  }

  close() {
    this.#routes.clear();
    this.#disposeTool?.();
    this.#disposeTool = null;
  }
}
