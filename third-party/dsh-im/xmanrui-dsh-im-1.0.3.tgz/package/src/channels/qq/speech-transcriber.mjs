const DEFAULT_MAX_VOICE_BYTES = 20 * 1024 * 1024;
const DEFAULT_DOWNLOAD_TIMEOUT_MS = 20_000;
const DEFAULT_TRANSCRIPTION_TIMEOUT_MS = 120_000;

export const QQ_ASR_API_KEY_REF = 'DSH_QQ_ASR_API_KEY';
export const QQ_MEDIA_HOSTS = Object.freeze([
  '.myqcloud.com',
  '.qpic.cn',
  '.qq.com',
  '.qq.com.cn',
  '.tencentcos.com',
  '.ugcimg.cn',
]);
export const DEFAULT_QQ_SPEECH_CONFIG = Object.freeze({
  enabled: false,
  baseUrl: 'http://127.0.0.1:8000/v1/',
  model: 'whisper-1',
  language: 'zh',
});

function clean(value) {
  return typeof value === 'string' && value.trim() ? value.trim() : null;
}

function isLoopback(hostname) {
  return ['127.0.0.1', 'localhost', '::1', '[::1]'].includes(hostname.toLowerCase());
}

export function normalizeQqAsrBaseUrl(value) {
  const raw = clean(value);
  if (!raw) throw new TypeError('ASR Base URL is required');
  const url = new URL(raw);
  if ((url.protocol !== 'https:' && !(url.protocol === 'http:' && isLoopback(url.hostname)))
    || url.username || url.password || url.search || url.hash) {
    throw new TypeError('ASR Base URL must use HTTPS or loopback HTTP without credentials, query, or fragment');
  }
  if (!url.pathname.endsWith('/')) url.pathname += '/';
  return url.toString();
}

export function normalizeQqSpeechConfig(value = DEFAULT_QQ_SPEECH_CONFIG) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new TypeError('QQ speech config must be an object');
  }
  const enabled = value.enabled === true;
  const baseUrl = normalizeQqAsrBaseUrl(value.baseUrl ?? DEFAULT_QQ_SPEECH_CONFIG.baseUrl);
  const model = clean(value.model ?? DEFAULT_QQ_SPEECH_CONFIG.model);
  const language = clean(value.language ?? DEFAULT_QQ_SPEECH_CONFIG.language);
  if (!model || model.length > 200) throw new TypeError('ASR model is invalid');
  if (!language || language.length > 32 || !/^[A-Za-z0-9-]+$/.test(language)) {
    throw new TypeError('ASR language is invalid');
  }
  return Object.freeze({ enabled, baseUrl, model, language });
}

function requestSignal(signal, timeoutMs) {
  const timeout = AbortSignal.timeout(timeoutMs);
  return signal ? AbortSignal.any([signal, timeout]) : timeout;
}

async function cancelBody(response) {
  try {
    await response?.body?.cancel?.();
  } catch {
    // The primary request failure is more useful than response cleanup failure.
  }
}

function allowedQqMediaUrl(value) {
  const url = new URL(value);
  if (url.protocol !== 'https:' || !QQ_MEDIA_HOSTS.some((rule) => (
    url.hostname === rule.slice(1) || url.hostname.endsWith(rule)
  ))) {
    throw new QqSpeechError(
      'voice-url-untrusted',
      'QQ voice download URL is not hosted by the messaging platform',
      '这条语音的下载地址无法验证，请重新发送。',
    );
  }
  return url;
}

export class QqSpeechError extends Error {
  constructor(code, message, userMessage, options = {}) {
    super(message, options);
    this.name = 'QqSpeechError';
    this.code = code;
    this.userMessage = userMessage;
  }
}

export function qqSpeechUserMessage(error) {
  return error instanceof QqSpeechError ? error.userMessage : null;
}

export async function fetchQqVoiceBuffer(url, {
  fetchImpl = fetch,
  signal,
  maxBytes = DEFAULT_MAX_VOICE_BYTES,
  timeoutMs = DEFAULT_DOWNLOAD_TIMEOUT_MS,
} = {}) {
  const target = allowedQqMediaUrl(url);
  const response = await fetchImpl(target, {
    method: 'GET',
    signal: requestSignal(signal, timeoutMs),
    redirect: 'manual',
  });
  if (Number.isInteger(response?.status) && response.status >= 300 && response.status < 400) {
    await cancelBody(response);
    throw new QqSpeechError(
      'voice-redirect-blocked',
      `QQ voice download redirect was blocked (HTTP ${response.status})`,
      '语音下载地址发生重定向，请重新发送。',
    );
  }
  if (!response?.ok) {
    await cancelBody(response);
    throw new QqSpeechError(
      'voice-download-failed',
      `QQ voice download failed with HTTP ${response?.status ?? 'unknown'}`,
      '语音下载失败，请重新发送。',
    );
  }
  const declaredLength = Number(response.headers?.get?.('content-length'));
  if (Number.isFinite(declaredLength) && declaredLength > maxBytes) {
    await cancelBody(response);
    throw new QqSpeechError(
      'voice-too-large',
      `QQ voice response declares ${declaredLength} bytes; the limit is ${maxBytes}`,
      '语音文件过大，请发送更短的语音。',
    );
  }
  const chunks = [];
  let size = 0;
  if (response.body?.[Symbol.asyncIterator]) {
    for await (const chunk of response.body) {
      const data = Buffer.from(chunk);
      size += data.length;
      if (size > maxBytes) {
        await response.body.cancel?.().catch?.(() => undefined);
        throw new QqSpeechError(
          'voice-too-large',
          `QQ voice response exceeded ${maxBytes} bytes`,
          '语音文件过大，请发送更短的语音。',
        );
      }
      chunks.push(data);
    }
    return Buffer.concat(chunks, size);
  }
  const data = Buffer.from(await response.arrayBuffer());
  if (data.length > maxBytes) {
    throw new QqSpeechError(
      'voice-too-large',
      `QQ voice response contains ${data.length} bytes; the limit is ${maxBytes}`,
      '语音文件过大，请发送更短的语音。',
    );
  }
  return data;
}

export class QqSpeechTranscriber {
  #configStore;
  #credentials;
  #fetch;
  #config = DEFAULT_QQ_SPEECH_CONFIG;
  #apiKey = null;

  constructor({ configStore, credentials, fetchImpl = fetch } = {}) {
    if (!configStore || !credentials
      || typeof credentials.resolve !== 'function'
      || typeof credentials.set !== 'function'
      || typeof credentials.unset !== 'function') {
      throw new TypeError('QqSpeechTranscriber requires config and credential stores');
    }
    if (typeof fetchImpl !== 'function') throw new TypeError('fetchImpl must be a function');
    this.#configStore = configStore;
    this.#credentials = credentials;
    this.#fetch = fetchImpl;
  }

  async load() {
    this.#config = normalizeQqSpeechConfig(this.#configStore.speech?.());
    const credential = await this.#credentials.resolve(QQ_ASR_API_KEY_REF).catch(() => undefined);
    this.#apiKey = clean(credential?.value);
    return this;
  }

  status() {
    return Object.freeze({
      ...this.#config,
      hasApiKey: Boolean(this.#apiKey),
    });
  }

  async update(input = {}) {
    const next = normalizeQqSpeechConfig(input);
    const previousConfig = this.#config;
    const previousApiKey = this.#apiKey;
    const suppliedApiKey = clean(input.apiKey);
    const clearApiKey = input.clearApiKey === true;
    if (suppliedApiKey && suppliedApiKey.length > 4_096) throw new TypeError('ASR API key is too long');
    try {
      if (suppliedApiKey) await this.#credentials.set(QQ_ASR_API_KEY_REF, suppliedApiKey);
      else if (clearApiKey) await this.#credentials.unset(QQ_ASR_API_KEY_REF);
      if (typeof this.#configStore.saveSpeech !== 'function') {
        throw new Error('QQ speech config persistence is unavailable');
      }
      await this.#configStore.saveSpeech(next);
    } catch (error) {
      if (previousApiKey) {
        await this.#credentials.set(QQ_ASR_API_KEY_REF, previousApiKey).catch(() => undefined);
      } else {
        await this.#credentials.unset(QQ_ASR_API_KEY_REF).catch(() => undefined);
      }
      this.#config = previousConfig;
      this.#apiKey = previousApiKey;
      throw error;
    }
    this.#config = next;
    if (suppliedApiKey) this.#apiKey = suppliedApiKey;
    else if (clearApiKey) this.#apiKey = null;
    return this.status();
  }

  async transcribe(attachment, { signal } = {}) {
    const platformTranscript = clean(attachment?.asr_refer_text);
    if (platformTranscript) return platformTranscript;
    if (!this.#config.enabled) {
      throw new QqSpeechError(
        'asr-disabled',
        'QQ ASR is disabled',
        '请先在设置 → 连接平台 → QQ 中启用并配置语音识别。',
      );
    }
    const voiceUrl = clean(attachment?.voice_wav_url);
    if (!voiceUrl) {
      throw new QqSpeechError(
        'voice-url-missing',
        'QQ voice attachment has no WAV download URL',
        '这条语音没有可用的 WAV 下载地址，请重新发送。',
      );
    }
    let audio;
    try {
      audio = await fetchQqVoiceBuffer(voiceUrl, {
        fetchImpl: this.#fetch,
        signal,
      });
    } catch (error) {
      if (error instanceof QqSpeechError || signal?.aborted || error?.name === 'AbortError') {
        throw error;
      }
      throw new QqSpeechError(
        'voice-download-failed',
        'Unable to download the QQ WAV attachment',
        '语音下载失败，请重新发送。',
        { cause: error },
      );
    }
    const form = new FormData();
    form.append('file', new Blob([audio], { type: 'audio/wav' }), 'qq-voice.wav');
    form.append('model', this.#config.model);
    form.append('language', this.#config.language);
    form.append('response_format', 'json');
    const headers = { accept: 'application/json' };
    if (this.#apiKey) headers.authorization = `Bearer ${this.#apiKey}`;
    const endpoint = new URL('audio/transcriptions', this.#config.baseUrl);
    let response;
    try {
      response = await this.#fetch(endpoint, {
        method: 'POST',
        headers,
        body: form,
        signal: requestSignal(signal, DEFAULT_TRANSCRIPTION_TIMEOUT_MS),
        redirect: 'manual',
      });
    } catch (error) {
      if (signal?.aborted || error?.name === 'AbortError') throw error;
      throw new QqSpeechError(
        'asr-unreachable',
        'Unable to reach the configured ASR service',
        '语音识别服务无法连接，请检查 QQ 语音识别设置。',
        { cause: error },
      );
    }
    if (Number.isInteger(response?.status) && response.status >= 300 && response.status < 400) {
      await cancelBody(response);
      throw new QqSpeechError(
        'asr-redirect-blocked',
        `ASR redirect was blocked (HTTP ${response.status})`,
        '语音识别服务返回了不允许的重定向。',
      );
    }
    if (!response?.ok) {
      await cancelBody(response);
      throw new QqSpeechError(
        'asr-request-failed',
        `ASR request failed with HTTP ${response?.status ?? 'unknown'}`,
        '语音识别失败，请检查服务地址、模型和 API Key。',
      );
    }
    let result;
    try {
      result = await response.json();
    } catch (error) {
      throw new QqSpeechError(
        'asr-response-invalid',
        'ASR service returned invalid JSON',
        '语音识别服务返回了无法读取的结果。',
        { cause: error },
      );
    }
    const transcript = clean(result?.text ?? result?.transcript);
    if (!transcript) {
      throw new QqSpeechError(
        'asr-transcript-empty',
        'ASR service returned an empty transcript',
        '没有识别到语音内容，请说话后重试。',
      );
    }
    return transcript;
  }
}
